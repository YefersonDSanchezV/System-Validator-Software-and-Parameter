import { useState, useRef } from "react";
import {
  Monitor, ShieldCheck, X, Eye, Pencil, Power, CheckCircle,
  XCircle, Download, Plus, ExternalLink, FileText, BookOpen,
  BarChart3, ArrowLeft, Upload, Printer, AlertCircle,
  ChevronDown, ChevronRight, Settings, Home, ClipboardList,
} from "lucide-react";

// ─── Constants ────────────────────────────────────────────────────────────────

const MODULOS = [
  "ADMISIONES", "CARTERA", "CONTABILIDAD", "CONTRATOS IPS",
  "FACTURACION", "HOSPITALIZACION", "INVENTARIOS", "PAGOS",
  "TESORERIA", "GENERALES & SEGURIDAD", "CITAS MEDICAS",
  "HISTORIAS CLINICAS", "ACTIVOS FIJOS", "NOMINA",
  "INFORMACION FINANCIERA NIIF", "GESTION GERENCIAL",
  "WEB CITAS MEDICAS", "PROGRAMACION DE CIRUGIAS",
];
const MODULOS_VALIDATOR = [...MODULOS, "OTROS"];

// ─── Types ────────────────────────────────────────────────────────────────────

type EstadoVersion = "activo" | "inactivo";
type EstadoObs = "aprobacion" | "rechazo";

interface Version {
  id: string;
  titulo: string;
  descripcion: string;
  enlace: string;
  fechaRegistro: string;
  estado: EstadoVersion;
}

interface Observacion {
  id: string;
  versionId: string;
  modulo: string;
  nombre: string;
  fechaHora: string;
  estado: EstadoObs;
  observacion: string;
  incidencia?: string;
  ruta?: string;
  firma?: string;
}

// ─── Seed Data ────────────────────────────────────────────────────────────────

const INIT_VERSIONS: Version[] = [
  {
    id: "v1",
    titulo: "Versión 4.2.1 — Actualización General",
    descripcion:
      "Mejoras en módulo de facturación, corrección de bugs en cartera y optimización de consultas en historias clínicas. Se implementaron nuevas validaciones en el proceso de cierre contable mensual.",
    enlace: "https://pruebas.sistema.com/v4.2.1",
    fechaRegistro: "2026-06-15",
    estado: "inactivo",
  },
  {
    id: "v2",
    titulo: "Versión 4.3.0 — Módulo NIIF",
    descripcion:
      "Implementación completa del módulo de Información Financiera NIIF, integración con informes gerenciales y nuevas vistas en tesorería. Mejora en el rendimiento de consultas de alto volumen.",
    enlace: "https://pruebas.sistema.com/v4.3.0",
    fechaRegistro: "2026-07-01",
    estado: "activo",
  },
  {
    id: "v3",
    titulo: "Versión 4.3.1 — Parche de Seguridad",
    descripcion:
      "Correcciones críticas de seguridad en autenticación, permisos de usuario y cifrado de datos sensibles del paciente conforme a normativa de habeas data.",
    enlace: "https://pruebas.sistema.com/v4.3.1",
    fechaRegistro: "2026-07-05",
    estado: "activo",
  },
];

const INIT_OBS: Observacion[] = [
  {
    id: "o1", versionId: "v2", modulo: "FACTURACION", nombre: "María González",
    fechaHora: "2026-07-03 09:15", estado: "aprobacion",
    observacion: "Módulo de facturación funciona correctamente. Todas las pruebas de factura electrónica pasaron satisfactoriamente.",
  },
  {
    id: "o2", versionId: "v2", modulo: "CARTERA", nombre: "Carlos Rodríguez",
    fechaHora: "2026-07-03 10:30", estado: "rechazo",
    observacion: "Error al generar reportes de cartera vencida con filtro por fecha.",
    incidencia: "INC-2024-089", ruta: "Módulo Cartera > Reportes > Cartera Vencida",
  },
  {
    id: "o3", versionId: "v2", modulo: "FACTURACION", nombre: "Ana Martínez",
    fechaHora: "2026-07-04 08:00", estado: "aprobacion",
    observacion: "Segunda revisión completada. Sin novedades adicionales.",
  },
  {
    id: "o4", versionId: "v2", modulo: "CONTABILIDAD", nombre: "Jorge López",
    fechaHora: "2026-07-04 11:20", estado: "aprobacion",
    observacion: "Módulo contable revisado y aprobado. Cierres mensuales funcionan correctamente.",
  },
  {
    id: "o5", versionId: "v2", modulo: "NOMINA", nombre: "Luisa Pérez",
    fechaHora: "2026-07-05 14:00", estado: "rechazo",
    observacion: "Falla en liquidación de prestaciones sociales para contratos de medio tiempo.",
    incidencia: "INC-2024-092", ruta: "Nómina > Liquidaciones > Prestaciones Sociales",
  },
  {
    id: "o6", versionId: "v3", modulo: "GENERALES & SEGURIDAD", nombre: "Roberto Silva",
    fechaHora: "2026-07-06 09:00", estado: "aprobacion",
    observacion: "Módulo de seguridad validado. Nuevas políticas de contraseña funcionan correctamente.",
  },
];

// ─── Shared UI Components ─────────────────────────────────────────────────────

function Modal({
  open, onClose, title, children, size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: "sm" | "md" | "lg" | "xl";
}) {
  if (!open) return null;
  const w = { sm: "max-w-md", md: "max-w-2xl", lg: "max-w-4xl", xl: "max-w-6xl" }[size];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      <div
        className={`relative bg-white rounded-2xl shadow-2xl w-full ${w} max-h-[90vh] flex flex-col border border-slate-200`}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 rounded-t-2xl shrink-0">
          <h2 className="font-semibold text-slate-800 text-sm">{title}</h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-200 transition-colors text-slate-500"
          >
            <X size={16} />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 p-6">{children}</div>
      </div>
    </div>
  );
}

function StatusBadge({ estado }: { estado: string }) {
  const map: Record<string, string> = {
    activo: "bg-emerald-100 text-emerald-700 ring-emerald-200/60",
    inactivo: "bg-slate-100 text-slate-500 ring-slate-200",
    aprobacion: "bg-blue-100 text-blue-700 ring-blue-200/60",
    rechazo: "bg-red-100 text-red-700 ring-red-200/60",
  };
  const labels: Record<string, string> = {
    activo: "Activo", inactivo: "Inactivo",
    aprobacion: "Aprobación", rechazo: "Rechazo",
  };
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ring-1 ${map[estado] ?? "bg-slate-100 text-slate-600 ring-slate-200"}`}
    >
      {labels[estado] ?? estado}
    </span>
  );
}

type BtnVariant = "primary" | "secondary" | "success" | "danger" | "ghost" | "warning" | "info";

function Btn({
  children, v = "primary", sm = false, onClick, disabled, type = "button", className = "",
}: {
  children: React.ReactNode;
  v?: BtnVariant;
  sm?: boolean;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const styles: Record<BtnVariant, string> = {
    primary: "bg-blue-700 text-white hover:bg-blue-800 border-blue-700",
    secondary: "bg-white text-slate-700 hover:bg-slate-50 border-slate-300",
    success: "bg-emerald-600 text-white hover:bg-emerald-700 border-emerald-600",
    danger: "bg-red-600 text-white hover:bg-red-700 border-red-600",
    ghost: "bg-transparent text-slate-600 hover:bg-slate-100 border-transparent",
    warning: "bg-amber-500 text-white hover:bg-amber-600 border-amber-500",
    info: "bg-sky-600 text-white hover:bg-sky-700 border-sky-600",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center gap-1.5 border rounded-lg font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-sm ${
        sm ? "px-2.5 py-1 text-xs" : "px-4 py-2 text-sm"
      } ${styles[v]} ${className}`}
    >
      {children}
    </button>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{label}</span>
      <span className="text-sm text-slate-800">{value}</span>
    </div>
  );
}

function FormInput({
  label, required: req, ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string; required?: boolean }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
        {label}
        {req && <span className="text-red-500 ml-1">*</span>}
      </label>
      <input
        {...props}
        className="px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all placeholder:text-slate-400"
      />
    </div>
  );
}

function FormTextarea({
  label, required: req, ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string; required?: boolean }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-semibold text-slate-600 uppercase tracking-wide">
        {label}
        {req && <span className="text-red-500 ml-1">*</span>}
      </label>
      <textarea
        {...props}
        className="px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all resize-none placeholder:text-slate-400"
      />
    </div>
  );
}

function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <h1 className="text-lg font-semibold text-slate-900">{title}</h1>
      {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="text-center py-12 text-slate-400 text-sm">{message}</div>
  );
}

// ─── Coordinator Module ───────────────────────────────────────────────────────

type CoordTab = "registro" | "consulta" | "detalles" | "reporteFirmas" | "reporteDetalles";

function CoordinatorModule({
  versions, setVersions, observaciones, setObservaciones,
}: {
  versions: Version[];
  setVersions: React.Dispatch<React.SetStateAction<Version[]>>;
  observaciones: Observacion[];
  setObservaciones: React.Dispatch<React.SetStateAction<Observacion[]>>;
}) {
  const [tab, setTab] = useState<CoordTab>("registro");
  const [reportsOpen, setReportsOpen] = useState(false);

  const navItems: { key: CoordTab; label: string; icon: React.ReactNode }[] = [
    { key: "registro", label: "Registro de Versión", icon: <Plus size={14} /> },
    { key: "consulta", label: "Consulta de Versión", icon: <ClipboardList size={14} /> },
    { key: "detalles", label: "Detalles de Validación", icon: <Eye size={14} /> },
  ];

  return (
    <div className="flex flex-col h-full">
      <nav className="bg-[#0f2d52] text-white px-4 flex items-center gap-0.5 h-11 shrink-0">
        <span className="text-[10px] font-bold tracking-widest uppercase text-blue-300/80 mr-4 shrink-0">
          COORDINADOR
        </span>
        {navItems.map((item) => (
          <button
            key={item.key}
            onClick={() => setTab(item.key)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium transition-all border-b-2 whitespace-nowrap ${
              tab === item.key
                ? "border-blue-400 text-white bg-white/5"
                : "border-transparent text-blue-200 hover:text-white hover:border-blue-300/50"
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
        <div className="relative">
          <button
            onClick={() => setReportsOpen(!reportsOpen)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium transition-all border-b-2 ${
              tab === "reporteFirmas" || tab === "reporteDetalles"
                ? "border-blue-400 text-white bg-white/5"
                : "border-transparent text-blue-200 hover:text-white hover:border-blue-300/50"
            }`}
          >
            <BarChart3 size={14} />
            Reportes
            <ChevronDown
              size={12}
              className={`transition-transform ${reportsOpen ? "rotate-180" : ""}`}
            />
          </button>
          {reportsOpen && (
            <div className="absolute top-full left-0 mt-1 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-30 min-w-56">
              <button
                onClick={() => { setTab("reporteFirmas"); setReportsOpen(false); }}
                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
              >
                Reporte de Firmas de Directivos
              </button>
              <button
                onClick={() => { setTab("reporteDetalles"); setReportsOpen(false); }}
                className="w-full text-left px-4 py-2.5 text-sm text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition-colors"
              >
                Reporte de Detalles de Validación
              </button>
            </div>
          )}
        </div>
      </nav>

      <div className="flex-1 overflow-auto bg-slate-50 p-6">
        {tab === "registro" && (
          <VersionRegistration versions={versions} setVersions={setVersions} />
        )}
        {tab === "consulta" && (
          <VersionQuery versions={versions} setVersions={setVersions} />
        )}
        {tab === "detalles" && (
          <ValidationDetails versions={versions} observaciones={observaciones} />
        )}
        {tab === "reporteFirmas" && (
          <ReportFirmas versions={versions} observaciones={observaciones} />
        )}
        {tab === "reporteDetalles" && (
          <ReportDetalles versions={versions} observaciones={observaciones} />
        )}
      </div>
    </div>
  );
}

// ─── 1. Version Registration ──────────────────────────────────────────────────

function VersionRegistration({
  setVersions,
}: {
  versions: Version[];
  setVersions: React.Dispatch<React.SetStateAction<Version[]>>;
}) {
  const [form, setForm] = useState({ titulo: "", descripcion: "", enlace: "" });
  const [saved, setSaved] = useState(false);

  function handleSave() {
    if (!form.titulo.trim() || !form.descripcion.trim() || !form.enlace.trim()) return;
    const nv: Version = {
      id: `v${Date.now()}`,
      titulo: form.titulo,
      descripcion: form.descripcion,
      enlace: form.enlace,
      fechaRegistro: new Date().toISOString().split("T")[0],
      estado: "activo",
    };
    setVersions((prev) => [nv, ...prev]);
    setForm({ titulo: "", descripcion: "", enlace: "" });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  return (
    <div className="max-w-2xl">
      <SectionHeader
        title="Registro de Versión del Sistema"
        subtitle="Complete los datos para registrar una nueva versión de pruebas."
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col gap-5">
        <FormInput
          label="Título (Versión del Sistema)"
          required
          placeholder="Ej: Versión 4.5.0 — Mejoras en Facturación"
          value={form.titulo}
          onChange={(e) => setForm({ ...form, titulo: e.target.value })}
        />
        <FormTextarea
          label="Descripción (Detalles de mejoras en la actualización)"
          required
          rows={5}
          placeholder="Describa los cambios, mejoras y correcciones de esta versión..."
          value={form.descripcion}
          onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
        />
        <FormInput
          label="Enlace (URL de la versión de pruebas)"
          required
          type="url"
          placeholder="https://pruebas.sistema.com/vX.X.X"
          value={form.enlace}
          onChange={(e) => setForm({ ...form, enlace: e.target.value })}
        />
        <div className="flex items-center gap-3 pt-1 border-t border-slate-100">
          <Btn v="primary" onClick={handleSave}>
            <Plus size={15} /> Guardar Versión
          </Btn>
          {saved && (
            <span className="text-sm text-emerald-600 flex items-center gap-1.5 font-medium">
              <CheckCircle size={15} /> Versión registrada exitosamente
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── 2. Version Query ─────────────────────────────────────────────────────────

function VersionQuery({
  versions, setVersions,
}: {
  versions: Version[];
  setVersions: React.Dispatch<React.SetStateAction<Version[]>>;
}) {
  const [detailsModal, setDetailsModal] = useState<Version | null>(null);
  const [editModal, setEditModal] = useState<Version | null>(null);
  const [editForm, setEditForm] = useState({ titulo: "", descripcion: "", enlace: "" });

  function openEdit(v: Version) {
    setEditForm({ titulo: v.titulo, descripcion: v.descripcion, enlace: v.enlace });
    setEditModal(v);
  }

  function saveEdit() {
    if (!editModal) return;
    setVersions((prev) =>
      prev.map((v) => (v.id === editModal.id ? { ...v, ...editForm } : v))
    );
    setEditModal(null);
  }

  function toggleEstado(id: string) {
    setVersions((prev) =>
      prev.map((v) =>
        v.id === id ? { ...v, estado: v.estado === "activo" ? "inactivo" : "activo" } : v
      )
    );
  }

  return (
    <div>
      <SectionHeader
        title="Consulta de Versiones del Sistema"
        subtitle={`${versions.length} versión(es) registradas`}
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              {["Título Versión", "Fecha Registro", "Estado", "Enlace", "Acciones"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {versions.map((v) => (
              <tr key={v.id} className="hover:bg-slate-50/80 transition-colors">
                <td className="px-4 py-3 font-medium text-slate-900 max-w-xs">{v.titulo}</td>
                <td className="px-4 py-3 text-slate-500 font-mono text-xs">{v.fechaRegistro}</td>
                <td className="px-4 py-3">
                  <StatusBadge estado={v.estado} />
                </td>
                <td className="px-4 py-3">
                  {v.estado === "activo" ? (
                    <a
                      href={v.enlace}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 text-xs font-medium"
                    >
                      <ExternalLink size={11} /> Ver enlace
                    </a>
                  ) : (
                    <span className="text-slate-400 text-xs flex items-center gap-1">
                      <XCircle size={11} /> Bloqueado
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <Btn v="ghost" sm onClick={() => setDetailsModal(v)}>
                      <Eye size={13} /> Consultar
                    </Btn>
                    <Btn v="ghost" sm onClick={() => openEdit(v)}>
                      <Pencil size={13} /> Editar
                    </Btn>
                    <Btn
                      v={v.estado === "activo" ? "warning" : "success"}
                      sm
                      onClick={() => toggleEstado(v.id)}
                    >
                      <Power size={13} />
                      {v.estado === "activo" ? "Inactivar" : "Activar"}
                    </Btn>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={!!detailsModal} onClose={() => setDetailsModal(null)} title="Detalles de la Versión">
        {detailsModal && (
          <div className="flex flex-col gap-5">
            <Field label="Título" value={detailsModal.titulo} />
            <Field label="Descripción" value={detailsModal.descripcion} />
            <div className="flex gap-6">
              <Field label="Estado" value={detailsModal.estado} />
              <Field label="Fecha de Registro" value={detailsModal.fechaRegistro} />
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Enlace
              </span>
              <a
                href={detailsModal.enlace}
                target="_blank"
                rel="noreferrer"
                className="text-sm text-blue-600 hover:underline flex items-center gap-1"
              >
                <ExternalLink size={13} /> {detailsModal.enlace}
              </a>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={!!editModal} onClose={() => setEditModal(null)} title="Editar Datos de Versión">
        {editModal && (
          <div className="flex flex-col gap-4">
            <FormInput
              label="Título"
              required
              value={editForm.titulo}
              onChange={(e) => setEditForm({ ...editForm, titulo: e.target.value })}
            />
            <FormTextarea
              label="Descripción"
              required
              rows={4}
              value={editForm.descripcion}
              onChange={(e) => setEditForm({ ...editForm, descripcion: e.target.value })}
            />
            <FormInput
              label="Enlace"
              required
              value={editForm.enlace}
              onChange={(e) => setEditForm({ ...editForm, enlace: e.target.value })}
            />
            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <Btn v="primary" onClick={saveEdit}>
                <CheckCircle size={15} /> Guardar Cambios
              </Btn>
              <Btn v="secondary" onClick={() => setEditModal(null)}>
                Cancelar
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ─── 3. Validation Details ────────────────────────────────────────────────────

function ValidationDetails({
  versions, observaciones,
}: {
  versions: Version[];
  observaciones: Observacion[];
}) {
  const [selectedVersion, setSelectedVersion] = useState<Version | null>(null);
  const [versionSelectorOpen, setVersionSelectorOpen] = useState(false);
  const [moduleDetailModal, setModuleDetailModal] = useState<string | null>(null);

  const obsForVersion = observaciones.filter((o) => o.versionId === selectedVersion?.id);

  function getStats(modulo: string) {
    const obs = obsForVersion.filter((o) => o.modulo === modulo);
    const total = obs.length;
    const aprobados = obs.filter((o) => o.estado === "aprobacion").length;
    const rechazados = total - aprobados;
    const sorted = [...obs].sort((a, b) => b.fechaHora.localeCompare(a.fechaHora));
    return {
      total,
      pctAp: total > 0 ? Math.round((aprobados / total) * 100) : 0,
      pctRe: total > 0 ? Math.round((rechazados / total) * 100) : 0,
      ultima: sorted[0]?.fechaHora ?? "—",
    };
  }

  const detailObs = moduleDetailModal
    ? obsForVersion.filter((o) => o.modulo === moduleDetailModal)
    : [];

  return (
    <div>
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold text-slate-900">Consulta de Detalles de Validación</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {selectedVersion
              ? `Versión: ${selectedVersion.titulo}`
              : "Seleccione una versión para consultar los detalles de validación por módulo."}
          </p>
        </div>
        <Btn v="primary" onClick={() => setVersionSelectorOpen(true)}>
          <FileText size={14} /> Seleccionar Versión
        </Btn>
      </div>

      {selectedVersion && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {["Módulo", "Última Observación", "% Aprobación", "% Rechazo", "Acción"].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {MODULOS.map((modulo) => {
                const s = getStats(modulo);
                return (
                  <tr key={modulo} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-2.5 font-semibold text-slate-700 text-xs">{modulo}</td>
                    <td className="px-4 py-2.5 text-slate-500 font-mono text-xs">{s.ultima}</td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-500 rounded-full"
                            style={{ width: `${s.pctAp}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold text-emerald-700 w-8">{s.pctAp}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red-500 rounded-full"
                            style={{ width: `${s.pctRe}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold text-red-700 w-8">{s.pctRe}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <Btn v="ghost" sm onClick={() => setModuleDetailModal(modulo)}>
                        <Eye size={13} /> Ver detalles
                      </Btn>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Modal
        open={versionSelectorOpen}
        onClose={() => setVersionSelectorOpen(false)}
        title="Seleccionar Versión"
        size="lg"
      >
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              {["Título", "Fecha Registro", "Estado", "Acción"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {versions.map((v) => (
              <tr key={v.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-medium text-slate-900">{v.titulo}</td>
                <td className="px-4 py-3 text-slate-500 font-mono text-xs">{v.fechaRegistro}</td>
                <td className="px-4 py-3">
                  <StatusBadge estado={v.estado} />
                </td>
                <td className="px-4 py-3">
                  <Btn
                    v="primary"
                    sm
                    onClick={() => {
                      setSelectedVersion(v);
                      setVersionSelectorOpen(false);
                    }}
                  >
                    Seleccionar
                  </Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Modal>

      <Modal
        open={!!moduleDetailModal}
        onClose={() => setModuleDetailModal(null)}
        title={`Detalles de Validación — ${moduleDetailModal}`}
        size="xl"
      >
        {selectedVersion && moduleDetailModal && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="col-span-2">
                <Field label="Título de la Versión" value={selectedVersion.titulo} />
              </div>
              <div className="col-span-2">
                <Field label="Descripción de la Versión" value={selectedVersion.descripcion} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-slate-700">
                  Cola de Observaciones
                </h3>
                <span className="text-xs text-slate-400 bg-slate-100 px-2.5 py-1 rounded-full font-medium">
                  {detailObs.length} registro(s)
                </span>
              </div>
              {detailObs.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-sm border border-dashed border-slate-200 rounded-xl">
                  No hay observaciones registradas para este módulo en esta versión.
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {detailObs.map((obs, i) => (
                    <div
                      key={obs.id}
                      className={`p-4 rounded-xl border ${
                        obs.estado === "aprobacion"
                          ? "border-emerald-200 bg-emerald-50"
                          : "border-red-200 bg-red-50"
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold text-slate-400 bg-white border border-slate-200 rounded-full w-5 h-5 flex items-center justify-center">
                            {i + 1}
                          </span>
                          <span className="font-semibold text-sm text-slate-900">{obs.nombre}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <StatusBadge estado={obs.estado} />
                          <span className="text-xs text-slate-500 font-mono">{obs.fechaHora}</span>
                        </div>
                      </div>
                      <p className="text-sm text-slate-700 leading-relaxed">{obs.observacion}</p>
                      {obs.estado === "rechazo" && (obs.incidencia || obs.ruta) && (
                        <div className="mt-3 pt-3 border-t border-red-200 grid grid-cols-2 gap-3">
                          {obs.incidencia && <Field label="Incidencia" value={obs.incidencia} />}
                          {obs.ruta && <Field label="Ruta" value={obs.ruta} />}
                        </div>
                      )}
                      {obs.firma && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                            Firma
                          </span>
                          <img src={obs.firma} alt="firma" className="max-h-14 object-contain" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

// ─── 4.1 Report Firmas ────────────────────────────────────────────────────────

function ReportFirmas({
  versions, observaciones,
}: {
  versions: Version[];
  observaciones: Observacion[];
}) {
  const [selectedVid, setSelectedVid] = useState("");
  const version = versions.find((v) => v.id === selectedVid);
  const filteredObs = observaciones.filter((o) => o.versionId === selectedVid);

  function generatePDF() {
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html><head><title>Reporte de Firmas</title>
<style>
  body{font-family:Arial,sans-serif;padding:40px;color:#0f172a;font-size:13px}
  h1{color:#0f2d52;font-size:18px;margin-bottom:4px}
  .sub{color:#64748b;font-size:12px;margin-bottom:28px}
  table{width:100%;border-collapse:collapse;margin-top:16px}
  th{background:#f1f5f9;padding:10px 12px;text-align:left;font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;border:1px solid #e2e8f0}
  td{padding:14px 12px;border:1px solid #e2e8f0;vertical-align:middle}
  .badge{padding:2px 10px;border-radius:99px;font-size:11px;font-weight:700}
  .ap{background:#d1fae5;color:#065f46}
  .re{background:#fee2e2;color:#991b1b}
  img.firma{max-width:110px;max-height:55px;display:block}
  .no-firma{font-size:11px;color:#94a3b8;font-style:italic}
  @media print{body{padding:20px}}
</style></head><body>
<h1>Reporte de Firmas de Directivos</h1>
<div class="sub">${version?.titulo ?? ""} &nbsp;|&nbsp; Generado: ${new Date().toLocaleDateString("es-CO", { dateStyle: "long" })}</div>
<table>
<tr><th>#</th><th>Nombre</th><th>Módulo</th><th>Fecha y Hora</th><th>Estado</th><th>Firma</th></tr>
${filteredObs
  .map(
    (o, i) => `<tr>
  <td style="color:#94a3b8;font-size:11px">${i + 1}</td>
  <td><strong>${o.nombre}</strong></td>
  <td style="font-size:11px">${o.modulo}</td>
  <td style="font-family:monospace;font-size:11px">${o.fechaHora}</td>
  <td><span class="badge ${o.estado === "aprobacion" ? "ap" : "re"}">${o.estado === "aprobacion" ? "Aprobación" : "Rechazo"}</span></td>
  <td>${o.firma ? `<img class="firma" src="${o.firma}" alt="firma"/>` : '<span class="no-firma">Sin firma</span>'}</td>
</tr>`
  )
  .join("")}
</table></body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 300);
  }

  return (
    <div>
      <SectionHeader
        title="Reporte de Firmas de Directivos"
        subtitle="Genera un documento PDF con las firmas y estados de validación por versión."
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-end gap-4 mb-6">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Filtrar por Versión
            </label>
            <select
              value={selectedVid}
              onChange={(e) => setSelectedVid(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 min-w-72"
            >
              <option value="">Seleccione una versión...</option>
              {versions.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.titulo}
                </option>
              ))}
            </select>
          </div>
          <Btn
            v="primary"
            onClick={generatePDF}
            disabled={!selectedVid || filteredObs.length === 0}
          >
            <Printer size={15} /> Generar PDF
          </Btn>
        </div>

        {selectedVid &&
          (filteredObs.length === 0 ? (
            <EmptyState message="No hay observaciones registradas para esta versión." />
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {["#", "Nombre", "Módulo", "Fecha/Hora", "Estado", "Firma"].map((h) => (
                    <th
                      key={h}
                      className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredObs.map((o, i) => (
                  <tr key={o.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-400 text-xs">{i + 1}</td>
                    <td className="px-4 py-3 font-medium text-slate-900">{o.nombre}</td>
                    <td className="px-4 py-3 text-xs text-slate-600 font-medium">{o.modulo}</td>
                    <td className="px-4 py-3 text-xs font-mono text-slate-500">{o.fechaHora}</td>
                    <td className="px-4 py-3">
                      <StatusBadge estado={o.estado} />
                    </td>
                    <td className="px-4 py-3">
                      {o.firma ? (
                        <img src={o.firma} alt="firma" className="h-10 object-contain" />
                      ) : (
                        <span className="text-xs text-slate-400 italic">Sin firma</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ))}
      </div>
    </div>
  );
}

// ─── 4.2 Report Detalles ──────────────────────────────────────────────────────

function ReportDetalles({
  versions, observaciones,
}: {
  versions: Version[];
  observaciones: Observacion[];
}) {
  const [selectedVid, setSelectedVid] = useState("");
  const version = versions.find((v) => v.id === selectedVid);
  const filteredObs = observaciones.filter((o) => o.versionId === selectedVid);

  function generatePDF() {
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html><head><title>Reporte de Validación</title>
<style>
  body{font-family:Arial,sans-serif;padding:40px;color:#0f172a;font-size:13px}
  h1{color:#0f2d52;font-size:18px;margin-bottom:4px}
  .sub{color:#64748b;font-size:12px;margin-bottom:28px}
  .obs{margin-bottom:16px;border:1px solid #e2e8f0;border-radius:10px;padding:16px;page-break-inside:avoid}
  .obs.ap{border-left:4px solid #10b981}
  .obs.re{border-left:4px solid #ef4444}
  .obs-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}
  .badge{padding:2px 10px;border-radius:99px;font-size:11px;font-weight:700}
  .apb{background:#d1fae5;color:#065f46}
  .reb{background:#fee2e2;color:#991b1b}
  .meta{font-size:11px;color:#64748b;margin-top:2px}
  .text{font-size:13px;color:#334155;line-height:1.5;margin-top:8px}
  .extra{font-size:11px;color:#64748b;margin-top:8px;padding-top:8px;border-top:1px solid #e2e8f0}
  @media print{body{padding:20px}}
</style></head><body>
<h1>Reporte de Detalles de Validación</h1>
<div class="sub">${version?.titulo ?? ""} &nbsp;|&nbsp; Generado: ${new Date().toLocaleDateString("es-CO", { dateStyle: "long" })}</div>
${filteredObs
  .map(
    (o) => `<div class="obs ${o.estado === "aprobacion" ? "ap" : "re"}">
  <div class="obs-head">
    <strong>${o.nombre}</strong>
    <span class="badge ${o.estado === "aprobacion" ? "apb" : "reb"}">${o.estado === "aprobacion" ? "Aprobación" : "Rechazo"}</span>
  </div>
  <div class="meta">Módulo: <strong>${o.modulo}</strong> &nbsp;|&nbsp; ${o.fechaHora}</div>
  <div class="text">${o.observacion}</div>
  ${o.incidencia || o.ruta ? `<div class="extra">${o.incidencia ? `Incidencia: <strong>${o.incidencia}</strong>` : ""}${o.ruta ? ` &nbsp;|&nbsp; Ruta: ${o.ruta}` : ""}</div>` : ""}
</div>`
  )
  .join("")}
</body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 300);
  }

  return (
    <div>
      <SectionHeader
        title="Reporte de Detalles de Validación"
        subtitle="Genera un reporte PDF con todos los registros de validación de una versión."
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-end gap-4 mb-6">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Filtrar por Versión
            </label>
            <select
              value={selectedVid}
              onChange={(e) => setSelectedVid(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 min-w-72"
            >
              <option value="">Seleccione una versión...</option>
              {versions.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.titulo}
                </option>
              ))}
            </select>
          </div>
          <Btn
            v="primary"
            onClick={generatePDF}
            disabled={!selectedVid || filteredObs.length === 0}
          >
            <Printer size={15} /> Generar PDF
          </Btn>
        </div>

        {selectedVid &&
          (filteredObs.length === 0 ? (
            <EmptyState message="No hay observaciones registradas para esta versión." />
          ) : (
            <div className="flex flex-col gap-3">
              {filteredObs.map((o) => (
                <div
                  key={o.id}
                  className={`p-4 rounded-xl border ${
                    o.estado === "aprobacion"
                      ? "border-emerald-200 bg-emerald-50 border-l-4 border-l-emerald-500"
                      : "border-red-200 bg-red-50 border-l-4 border-l-red-500"
                  }`}
                >
                  <div className="flex justify-between items-start mb-1.5">
                    <div>
                      <span className="font-semibold text-slate-900 text-sm">{o.nombre}</span>
                      <span className="text-xs text-slate-500 ml-2">— {o.modulo}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusBadge estado={o.estado} />
                      <span className="text-xs font-mono text-slate-400">{o.fechaHora}</span>
                    </div>
                  </div>
                  <p className="text-sm text-slate-700 leading-relaxed">{o.observacion}</p>
                  {(o.incidencia || o.ruta) && (
                    <div className="mt-2.5 pt-2.5 border-t border-red-200 flex gap-6">
                      {o.incidencia && <Field label="Incidencia" value={o.incidencia} />}
                      {o.ruta && <Field label="Ruta" value={o.ruta} />}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
      </div>
    </div>
  );
}

// ─── Validator Module ─────────────────────────────────────────────────────────

type ValidatorTab = "registro" | "boletines" | "manuales";

function ValidatorModule({
  versions, observaciones, setObservaciones,
}: {
  versions: Version[];
  observaciones: Observacion[];
  setObservaciones: React.Dispatch<React.SetStateAction<Observacion[]>>;
}) {
  const [tab, setTab] = useState<ValidatorTab>("registro");

  const navItems: { key: ValidatorTab; label: string; icon: React.ReactNode }[] = [
    { key: "registro", label: "Registro de Validación", icon: <ClipboardList size={14} /> },
    { key: "boletines", label: "Boletines", icon: <FileText size={14} /> },
    { key: "manuales", label: "Manuales de Usuarios", icon: <BookOpen size={14} /> },
  ];

  return (
    <div className="flex flex-col h-full">
      <nav className="bg-[#14532d] text-white px-4 flex items-center gap-0.5 h-11 shrink-0">
        <span className="text-[10px] font-bold tracking-widest uppercase text-emerald-300/80 mr-4 shrink-0">
          VALIDADOR
        </span>
        {navItems.map((item) => (
          <button
            key={item.key}
            onClick={() => setTab(item.key)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium transition-all border-b-2 whitespace-nowrap ${
              tab === item.key
                ? "border-emerald-400 text-white bg-white/5"
                : "border-transparent text-emerald-200 hover:text-white hover:border-emerald-300/50"
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>
      <div className="flex-1 overflow-auto bg-slate-50 p-6">
        {tab === "registro" && (
          <ValidationRegistration
            versions={versions}
            observaciones={observaciones}
            setObservaciones={setObservaciones}
          />
        )}
        {tab === "boletines" && <Boletines />}
        {tab === "manuales" && <ManualesUsuarios />}
      </div>
    </div>
  );
}

// ─── Validator: Registration ──────────────────────────────────────────────────

function ValidationRegistration({
  versions, observaciones, setObservaciones,
}: {
  versions: Version[];
  observaciones: Observacion[];
  setObservaciones: React.Dispatch<React.SetStateAction<Observacion[]>>;
}) {
  const [detailsVersion, setDetailsVersion] = useState<Version | null>(null);
  const [detailForm, setDetailForm] = useState({ modulo: "", otrosText: "" });
  const [approvalOpen, setApprovalOpen] = useState(false);
  const [rejectionOpen, setRejectionOpen] = useState(false);
  const [apForm, setApForm] = useState({ observacion: "", nombre: "", firma: "" });
  const [reForm, setReForm] = useState({ incidencia: "", ruta: "", observacion: "", nombre: "", firma: "" });
  const firmaApRef = useRef<HTMLInputElement>(null);
  const firmaReRef = useRef<HTMLInputElement>(null);

  function openDetails(v: Version) {
    setDetailForm({ modulo: "", otrosText: "" });
    setDetailsVersion(v);
  }

  const resolvedModulo =
    detailForm.modulo === "OTROS" ? detailForm.otrosText : detailForm.modulo;
  const moduloValid =
    !!detailForm.modulo && (detailForm.modulo !== "OTROS" || !!detailForm.otrosText.trim());

  function handleFirma(e: React.ChangeEvent<HTMLInputElement>, type: "ap" | "re") {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const res = ev.target?.result as string;
      if (type === "ap") setApForm((f) => ({ ...f, firma: res }));
      else setReForm((f) => ({ ...f, firma: res }));
    };
    reader.readAsDataURL(file);
  }

  function submitApproval() {
    if (!detailsVersion || !apForm.observacion.trim() || !apForm.nombre.trim()) return;
    setObservaciones((prev) => [
      ...prev,
      {
        id: `o${Date.now()}`,
        versionId: detailsVersion.id,
        modulo: resolvedModulo,
        nombre: apForm.nombre,
        fechaHora: new Date().toISOString().replace("T", " ").slice(0, 16),
        estado: "aprobacion",
        observacion: apForm.observacion,
        firma: apForm.firma || undefined,
      },
    ]);
    setApprovalOpen(false);
    setApForm({ observacion: "", nombre: "", firma: "" });
    setDetailsVersion(null);
  }

  function submitRejection() {
    if (!detailsVersion || !reForm.observacion.trim() || !reForm.nombre.trim()) return;
    setObservaciones((prev) => [
      ...prev,
      {
        id: `o${Date.now()}`,
        versionId: detailsVersion.id,
        modulo: resolvedModulo,
        nombre: reForm.nombre,
        fechaHora: new Date().toISOString().replace("T", " ").slice(0, 16),
        estado: "rechazo",
        observacion: reForm.observacion,
        incidencia: reForm.incidencia || undefined,
        ruta: reForm.ruta || undefined,
        firma: reForm.firma || undefined,
      },
    ]);
    setRejectionOpen(false);
    setReForm({ incidencia: "", ruta: "", observacion: "", nombre: "", firma: "" });
    setDetailsVersion(null);
  }

  const obsCountForVersion = (vid: string) =>
    observaciones.filter((o) => o.versionId === vid).length;

  return (
    <div>
      <SectionHeader
        title="Registro de Validación del Sistema"
        subtitle="Versiones disponibles para validación. Registre sus observaciones, aprobaciones o rechazos."
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              {["Título Versión", "Fecha Registro", "Estado", "Enlace", "Obs.", "Acciones"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {versions.map((v) => (
              <tr key={v.id} className="hover:bg-slate-50/80 transition-colors">
                <td className="px-4 py-3 font-medium text-slate-900 max-w-xs">{v.titulo}</td>
                <td className="px-4 py-3 text-slate-500 font-mono text-xs">{v.fechaRegistro}</td>
                <td className="px-4 py-3">
                  <StatusBadge estado={v.estado} />
                </td>
                <td className="px-4 py-3">
                  {v.estado === "activo" ? (
                    <a
                      href={v.enlace}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 text-xs font-medium"
                    >
                      <ExternalLink size={11} /> Ver enlace
                    </a>
                  ) : (
                    <span className="text-slate-400 text-xs flex items-center gap-1">
                      <XCircle size={11} /> Bloqueado
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <span className="text-xs font-mono font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                    {obsCountForVersion(v.id)}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <Btn v="ghost" sm onClick={() => openDetails(v)}>
                      <Eye size={13} /> Consultar
                    </Btn>
                    <Btn
                      v="primary"
                      sm
                      onClick={() => openDetails(v)}
                      disabled={v.estado !== "activo"}
                    >
                      <Plus size={13} /> Registrar Obs.
                    </Btn>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Details + observation modal */}
      <Modal
        open={!!detailsVersion}
        onClose={() => setDetailsVersion(null)}
        title="Detalles de Versión y Registro de Observación"
        size="lg"
      >
        {detailsVersion && (
          <div className="flex flex-col gap-5">
            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="col-span-2">
                <Field label="Título de la Versión" value={detailsVersion.titulo} />
              </div>
              <Field label="Fecha de Registro" value={detailsVersion.fechaRegistro} />
              <Field label="Estado" value={detailsVersion.estado} />
              <div className="col-span-2">
                <Field label="Descripción de la Compilación" value={detailsVersion.descripcion} />
              </div>
              <div className="col-span-2 flex flex-col gap-0.5">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  Enlace URL
                </span>
                <a
                  href={detailsVersion.enlace}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm text-blue-600 hover:underline flex items-center gap-1"
                >
                  <ExternalLink size={13} /> {detailsVersion.enlace}
                </a>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Módulo a Validar <span className="text-red-500">*</span>
                </label>
                <select
                  value={detailForm.modulo}
                  onChange={(e) => setDetailForm({ ...detailForm, modulo: e.target.value })}
                  className="px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Seleccione un módulo...</option>
                  {MODULOS_VALIDATOR.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              {detailForm.modulo === "OTROS" && (
                <FormInput
                  label="Especifique la ruta o nombre del módulo"
                  required
                  placeholder="Ej: Configuración > Parámetros > Monedas"
                  value={detailForm.otrosText}
                  onChange={(e) => setDetailForm({ ...detailForm, otrosText: e.target.value })}
                />
              )}
            </div>

            <div className="flex gap-3 pt-3 border-t border-slate-200">
              <Btn
                v="success"
                onClick={() => setApprovalOpen(true)}
                disabled={!moduloValid || detailsVersion.estado !== "activo"}
              >
                <CheckCircle size={15} /> Aprobar
              </Btn>
              <Btn
                v="danger"
                onClick={() => setRejectionOpen(true)}
                disabled={!moduloValid || detailsVersion.estado !== "activo"}
              >
                <XCircle size={15} /> Rechazar
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Approval modal */}
      <Modal open={approvalOpen} onClose={() => setApprovalOpen(false)} title="Registrar Aprobación" size="md">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2.5 p-3 bg-emerald-50 rounded-xl border border-emerald-200">
            <CheckCircle size={18} className="text-emerald-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-emerald-800">Registro de Aprobación</p>
              <p className="text-xs text-emerald-600">Módulo: {resolvedModulo}</p>
            </div>
          </div>
          <FormTextarea
            label="Observación"
            required
            rows={4}
            placeholder="Describa las pruebas realizadas y los resultados obtenidos..."
            value={apForm.observacion}
            onChange={(e) => setApForm({ ...apForm, observacion: e.target.value })}
          />
          <FormInput
            label="Nombre de quien registra"
            required
            placeholder="Nombre completo"
            value={apForm.nombre}
            onChange={(e) => setApForm({ ...apForm, nombre: e.target.value })}
          />
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Firma (imagen .jpg / .png)
            </label>
            <div
              onClick={() => firmaApRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-xl p-5 text-center cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-all"
            >
              {apForm.firma ? (
                <img
                  src={apForm.firma}
                  alt="firma"
                  className="max-h-20 mx-auto object-contain"
                />
              ) : (
                <div className="flex flex-col items-center gap-2 text-slate-400">
                  <Upload size={22} />
                  <span className="text-xs">Haga clic para cargar la imagen de firma</span>
                </div>
              )}
            </div>
            <input
              ref={firmaApRef}
              type="file"
              accept=".jpg,.jpeg,.png"
              className="hidden"
              onChange={(e) => handleFirma(e, "ap")}
            />
          </div>
          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <Btn
              v="success"
              onClick={submitApproval}
              disabled={!apForm.observacion.trim() || !apForm.nombre.trim()}
            >
              <CheckCircle size={15} /> Guardar Aprobación
            </Btn>
            <Btn v="secondary" onClick={() => setApprovalOpen(false)}>
              Cancelar
            </Btn>
          </div>
        </div>
      </Modal>

      {/* Rejection modal */}
      <Modal open={rejectionOpen} onClose={() => setRejectionOpen(false)} title="Registrar Rechazo / Incidencia" size="md">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2.5 p-3 bg-red-50 rounded-xl border border-red-200">
            <AlertCircle size={18} className="text-red-600 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-red-800">Registro de Rechazo</p>
              <p className="text-xs text-red-600">Módulo: {resolvedModulo}</p>
            </div>
          </div>
          <FormInput
            label="Incidencia"
            placeholder="Ej: INC-2024-001"
            value={reForm.incidencia}
            onChange={(e) => setReForm({ ...reForm, incidencia: e.target.value })}
          />
          <FormInput
            label="Ruta"
            placeholder="Módulo > Submenú > Opción"
            value={reForm.ruta}
            onChange={(e) => setReForm({ ...reForm, ruta: e.target.value })}
          />
          <FormTextarea
            label="Observación"
            required
            rows={4}
            placeholder="Describa el error o problema encontrado..."
            value={reForm.observacion}
            onChange={(e) => setReForm({ ...reForm, observacion: e.target.value })}
          />
          <FormInput
            label="Nombre de quien registra"
            required
            placeholder="Nombre completo"
            value={reForm.nombre}
            onChange={(e) => setReForm({ ...reForm, nombre: e.target.value })}
          />
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Firma (imagen .jpg / .png)
            </label>
            <div
              onClick={() => firmaReRef.current?.click()}
              className="border-2 border-dashed border-slate-300 rounded-xl p-5 text-center cursor-pointer hover:border-red-400 hover:bg-red-50 transition-all"
            >
              {reForm.firma ? (
                <img
                  src={reForm.firma}
                  alt="firma"
                  className="max-h-20 mx-auto object-contain"
                />
              ) : (
                <div className="flex flex-col items-center gap-2 text-slate-400">
                  <Upload size={22} />
                  <span className="text-xs">Haga clic para cargar la imagen de firma</span>
                </div>
              )}
            </div>
            <input
              ref={firmaReRef}
              type="file"
              accept=".jpg,.jpeg,.png"
              className="hidden"
              onChange={(e) => handleFirma(e, "re")}
            />
          </div>
          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <Btn
              v="danger"
              onClick={submitRejection}
              disabled={!reForm.observacion.trim() || !reForm.nombre.trim()}
            >
              <XCircle size={15} /> Guardar Rechazo
            </Btn>
            <Btn v="secondary" onClick={() => setRejectionOpen(false)}>
              Cancelar
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ─── Boletines ────────────────────────────────────────────────────────────────

function Boletines() {
  const items = [
    {
      id: 1,
      titulo: "Boletín Técnico #24 — Actualización Módulo NIIF 2026",
      fecha: "2026-07-01",
      tipo: "Técnico",
      descripcion:
        "Cambios en estándares NIIF para el período 2026 y su impacto en el módulo de información financiera y reportes gerenciales.",
    },
    {
      id: 2,
      titulo: "Boletín #23 — Nuevas Funcionalidades Q2 2026",
      fecha: "2026-06-15",
      tipo: "Funcional",
      descripcion:
        "Resumen de las mejoras implementadas durante el segundo trimestre de 2026, incluyendo optimizaciones en facturación y cartera.",
    },
    {
      id: 3,
      titulo: "Boletín de Seguridad #07 — Políticas de Acceso",
      fecha: "2026-05-20",
      tipo: "Seguridad",
      descripcion:
        "Actualización de políticas de contraseñas, doble factor de autenticación y control de acceso por roles.",
    },
    {
      id: 4,
      titulo: "Boletín #22 — Integración Web Citas Médicas",
      fecha: "2026-04-10",
      tipo: "Funcional",
      descripcion:
        "Nuevas funcionalidades del módulo web de citas médicas: confirmación automática, recordatorios por SMS y cancelación en línea.",
    },
  ];
  const colores: Record<string, string> = {
    Técnico: "bg-blue-100 text-blue-700",
    Funcional: "bg-violet-100 text-violet-700",
    Seguridad: "bg-amber-100 text-amber-700",
  };
  return (
    <div>
      <SectionHeader
        title="Boletines"
        subtitle="Comunicados y boletines informativos del sistema."
      />
      <div className="grid gap-4">
        {items.map((b) => (
          <div
            key={b.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex items-start gap-4 hover:border-slate-300 transition-colors"
          >
            <div className="p-3 bg-slate-100 rounded-xl shrink-0">
              <FileText size={20} className="text-slate-500" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wide ${colores[b.tipo]}`}
                >
                  {b.tipo}
                </span>
                <span className="text-xs text-slate-400 font-mono">{b.fecha}</span>
              </div>
              <h3 className="font-semibold text-slate-900 text-sm">{b.titulo}</h3>
              <p className="text-sm text-slate-500 mt-1 leading-relaxed">{b.descripcion}</p>
            </div>
            <Btn v="secondary" sm className="shrink-0">
              <Download size={13} /> Descargar
            </Btn>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Manuales ─────────────────────────────────────────────────────────────────

function ManualesUsuarios() {
  const items = [
    { id: 1, modulo: "FACTURACION", titulo: "Manual de Usuario — Módulo Facturación v4.3", version: "4.3", fecha: "2026-06-20", paginas: 84 },
    { id: 2, modulo: "CONTABILIDAD", titulo: "Manual de Usuario — Módulo Contable v4.3", version: "4.3", fecha: "2026-06-20", paginas: 112 },
    { id: 3, modulo: "CARTERA", titulo: "Manual de Usuario — Cartera y Cobranzas v4.2", version: "4.2", fecha: "2026-05-15", paginas: 67 },
    { id: 4, modulo: "NOMINA", titulo: "Manual de Usuario — Nómina y RRHH v4.2", version: "4.2", fecha: "2026-05-15", paginas: 98 },
    { id: 5, modulo: "INFORMACION FINANCIERA NIIF", titulo: "Manual de Usuario — Módulo NIIF v4.3", version: "4.3", fecha: "2026-07-01", paginas: 56 },
    { id: 6, modulo: "HISTORIAS CLINICAS", titulo: "Manual de Usuario — Historias Clínicas v4.2", version: "4.2", fecha: "2026-05-15", paginas: 134 },
    { id: 7, modulo: "CITAS MEDICAS", titulo: "Manual de Usuario — Citas Médicas v4.2", version: "4.2", fecha: "2026-04-10", paginas: 48 },
  ];
  return (
    <div>
      <SectionHeader
        title="Manuales de Usuarios"
        subtitle="Documentación oficial por módulo del sistema."
      />
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              {["Módulo", "Título", "Versión", "Fecha", "Páginas", "Descarga"].map((h) => (
                <th
                  key={h}
                  className="px-4 py-3 text-left text-[10px] font-bold text-slate-400 uppercase tracking-wider"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                <td className="px-4 py-3 text-xs font-bold text-blue-700">{m.modulo}</td>
                <td className="px-4 py-3 font-medium text-slate-900">{m.titulo}</td>
                <td className="px-4 py-3 text-slate-500 text-xs font-mono">v{m.version}</td>
                <td className="px-4 py-3 text-slate-500 text-xs font-mono">{m.fecha}</td>
                <td className="px-4 py-3 text-slate-500 text-xs font-mono">{m.paginas} págs.</td>
                <td className="px-4 py-3">
                  <Btn v="primary" sm>
                    <Download size={13} /> PDF
                  </Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Home / Module Selector ───────────────────────────────────────────────────

function ModuleSelector({ onSelect }: { onSelect: (m: "coordinator" | "validator") => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-[#0c2340] to-slate-950 flex flex-col items-center justify-center p-8">
      <div className="text-center mb-14">
        <div className="inline-flex items-center gap-3.5 mb-5">
          <div className="w-13 h-13 bg-blue-500/15 border border-blue-500/30 rounded-2xl flex items-center justify-center p-3">
            <Monitor size={26} className="text-blue-400" />
          </div>
          <div className="text-left">
            <h1 className="text-2xl font-bold text-white tracking-tight">SisValida</h1>
            <p className="text-blue-300/70 text-xs tracking-widest uppercase font-semibold">
              Sistema de Validación de Software
            </p>
          </div>
        </div>
        <div className="w-px h-8 bg-white/10 mx-auto mb-5" />
        <p className="text-slate-400 text-sm">
          Seleccione el módulo al cual desea acceder
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 w-full max-w-2xl">
        <button
          onClick={() => onSelect("coordinator")}
          className="group bg-white/4 hover:bg-white/7 border border-white/8 hover:border-blue-500/40 rounded-3xl p-8 text-left transition-all duration-200 hover:shadow-2xl hover:shadow-blue-500/10"
        >
          <div className="w-12 h-12 bg-blue-500/15 group-hover:bg-blue-500/25 border border-blue-500/20 rounded-2xl flex items-center justify-center mb-6 transition-all">
            <Settings size={22} className="text-blue-400" />
          </div>
          <h2 className="text-base font-bold text-white mb-2">
            Coordinador de Sistemas
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Gestión de versiones del sistema, consulta de validaciones por módulo y generación de reportes ejecutivos.
          </p>
          <div className="mt-6 flex items-center gap-1.5 text-blue-400 text-xs font-semibold group-hover:gap-2.5 transition-all uppercase tracking-wide">
            Ingresar <ChevronRight size={14} />
          </div>
        </button>

        <button
          onClick={() => onSelect("validator")}
          className="group bg-white/4 hover:bg-white/7 border border-white/8 hover:border-emerald-500/40 rounded-3xl p-8 text-left transition-all duration-200 hover:shadow-2xl hover:shadow-emerald-500/10"
        >
          <div className="w-12 h-12 bg-emerald-500/15 group-hover:bg-emerald-500/25 border border-emerald-500/20 rounded-2xl flex items-center justify-center mb-6 transition-all">
            <ShieldCheck size={22} className="text-emerald-400" />
          </div>
          <h2 className="text-base font-bold text-white mb-2">
            Validación del Sistema
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Registro de observaciones, aprobaciones y rechazos por módulo. Acceso a boletines y manuales de usuario.
          </p>
          <div className="mt-6 flex items-center gap-1.5 text-emerald-400 text-xs font-semibold group-hover:gap-2.5 transition-all uppercase tracking-wide">
            Ingresar <ChevronRight size={14} />
          </div>
        </button>
      </div>

      <p className="text-slate-600 text-xs mt-12">
        © 2026 SisValida — Sistema de Control de Versiones para Producción
      </p>
    </div>
  );
}

// ─── App Root ─────────────────────────────────────────────────────────────────

export default function App() {
  const [module, setModule] = useState<"home" | "coordinator" | "validator">("home");
  const [versions, setVersions] = useState<Version[]>(INIT_VERSIONS);
  const [observaciones, setObservaciones] = useState<Observacion[]>(INIT_OBS);

  if (module === "home") {
    return <ModuleSelector onSelect={setModule} />;
  }

  const isCoord = module === "coordinator";

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Global top bar */}
      <div className="bg-slate-950 text-white px-5 h-9 flex items-center justify-between shrink-0 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <Monitor size={15} className="text-blue-400" />
          <span className="text-xs font-bold text-white">SisValida</span>
          <span className="text-slate-600 text-xs">/</span>
          <span className="text-xs text-slate-400">
            {isCoord ? "Coordinador de Sistemas" : "Módulo de Validación"}
          </span>
        </div>
        <button
          onClick={() => setModule("home")}
          className="text-[11px] text-slate-500 hover:text-white flex items-center gap-1 transition-colors"
        >
          <Home size={12} /> Inicio
        </button>
      </div>

      <div className="flex-1 overflow-hidden">
        {isCoord ? (
          <CoordinatorModule
            versions={versions}
            setVersions={setVersions}
            observaciones={observaciones}
            setObservaciones={setObservaciones}
          />
        ) : (
          <ValidatorModule
            versions={versions}
            observaciones={observaciones}
            setObservaciones={setObservaciones}
          />
        )}
      </div>
    </div>
  );
}
